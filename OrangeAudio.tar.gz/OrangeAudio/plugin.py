import os
import json
import re
from enigma import eTimer
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap, NumberActionMap
from Components.Sources.StaticText import StaticText
from Components.Input import Input
from Components.config import config, ConfigSubsection, ConfigText, ConfigYesNo, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Plugins.Plugin import PluginDescriptor
from Components.FileList import FileList
from Components.Label import Label
from twisted.web.client import getPage
from Screens.Console import Console
import six

# Plugin version
PLUGIN_VERSION = "1.1"

config.plugins.OrangeAudio = ConfigSubsection()
config.plugins.OrangeAudio.token = ConfigText(default="0123456789", fixed_size=False)
config.plugins.OrangeAudio.activated = ConfigYesNo(default=False)
config.plugins.OrangeAudio.target_plugin = ConfigSelection(choices=[
    ("IPAudioPro", "IPAudioPro"),
    ("IPAudioPlus", "IPAudioPlus")
], default="IPAudioPro")
config.plugins.OrangeAudio.merge_mode = ConfigSelection(choices=[
    ("merge_replace", "Merge and Replace Token"),
    ("merge_only", "Merge Only")
], default="merge_replace")
config.plugins.OrangeAudio.file_source = ConfigSelection(choices=[
    ("default", "Default File"),
    ("custom", "Custom File")
], default="default")
config.plugins.OrangeAudio.custom_file = ConfigText(default="", fixed_size=False)
config.plugins.OrangeAudio.token_path = ConfigText(default="/etc/enigma2/", fixed_size=False)

class FileSelect(Screen):
    skin = """
        <screen name="FileSelect" position="center,center" size="820,590" title="Select File" flags="wfBorder">
            <eLabel name="" position="10,550" size="5,40" backgroundColor="red" foregroundColor="red" />
            <eLabel name="" position="210,550" size="5,40" backgroundColor="green" foregroundColor="green" />
            <widget name="list_head" position="10,10" size="800,38" foregroundColor="#00cccc40" font="Regular; 26" />
            <widget source="key_red" render="Label" position="20,550" zPosition="1" size="170,40" font="Regular;26" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget source="key_green" render="Label" position="220,550" zPosition="1" size="170,40" font="Regular;26" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget name="checkList" position="10,50" zPosition="2" size="800,483" scrollbarMode="showOnDemand" />
        </screen>"""

    def __init__(self, session, currentDir, selectFiles=True):
        Screen.__init__(self, session)
        self.selectFiles = selectFiles
        self.setTitle(_("Select File" if selectFiles else "Select Folder"))

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"],
        {
            "cancel": self.exit,
            "red": self.exit,
            "green": self.saveSelection,
            "ok": self.okClicked,
            "left": self.left,
            "right": self.right,
            "down": self.down,
            "up": self.up
        }, -1)

        self["key_red"] = StaticText(_("Close"))
        self["key_green"] = StaticText(_("Select"))

        self["list_head"] = Label()

        # Use empty pattern when selecting folders, show all files when selecting files
        pattern = "" if not selectFiles else None
        self.filelist = FileList(currentDir, matchingPattern=pattern, showDirectories=True, showFiles=selectFiles)
        self["checkList"] = self.filelist
        self.onLayoutFinish.append(self.layoutFinished)
        self.updateHead()

    def layoutFinished(self):
        idx = 0
        self["checkList"].moveToIndex(idx)

    def up(self):
        self["checkList"].up()
        self.updateHead()

    def down(self):
        self["checkList"].down()
        self.updateHead()

    def left(self):
        self["checkList"].pageUp()
        self.updateHead()

    def right(self):
        self["checkList"].pageDown()
        self.updateHead()

    def updateHead(self):
        curdir = self["checkList"].getCurrentDirectory()
        self["list_head"].setText(curdir)

    def saveSelection(self):
        if self.selectFiles:
            selected = self["checkList"].getFilename()
            if selected and not os.path.isdir(selected):
                self.close(selected)
            else:
                self.session.open(MessageBox, _("Please select a file, not a directory."), MessageBox.TYPE_ERROR, timeout=10)
        else:
            selected = self["checkList"].getCurrentDirectory()
            self.close(selected)

    def okClicked(self):
        if self.filelist.canDescent():
            self.filelist.descent()
            self.updateHead()
        elif self.selectFiles:
            self.saveSelection()

    def exit(self):
        self.close(None)

class OrangeAudioSetup(Screen, ConfigListScreen):
    skin = """
        <screen position="center,center" size="800,380" title="Orange Audio Setup" flags="wfBorder">
            <widget name="config" position="10,10" size="780,315" scrollbarMode="showOnDemand" itemHeight="45" />
            <widget source="key_red" render="Label" position="20,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget source="key_green" render="Label" position="220,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget source="key_yellow" render="Label" position="420,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget source="key_blue" render="Label" position="620,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <eLabel name="" position="10,330" size="5,40" backgroundColor="red" foregroundColor="red" />
            <eLabel name="" position="210,330" size="5,40" backgroundColor="green" foregroundColor="green" />
            <eLabel name="" position="410,330" size="5,40" backgroundColor="yellow" foregroundColor="yellow" />
            <eLabel name="" position="610,330" size="5,40" backgroundColor="blue" foregroundColor="blue" />
        </screen>
    """
    
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.setup_title = _("Orange Audio Setup")
        self.new_version = None
        self.new_description = None
        self.list = []  # Initialize the config list
        
        # Initialize ConfigListScreen first
        ConfigListScreen.__init__(self, self.list, session=session)
        
        # Then setup the rest of the UI
        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))
        self["key_yellow"] = StaticText(_("Import Token"))
        self["key_blue"] = StaticText(_("Export Token"))
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions"],
        {
            "green": self.save,
            "red": self.cancel,
            "cancel": self.cancel,
            "ok": self.ok,
            "info": self.showAuthorInfo,
            "yellow": self.importToken,
            "blue": self.exportToken,
        }, -2)
        
        self["numberActions"] = NumberActionMap(["NumberActions"],
        {
            "0": self.keyNumberGlobal,
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
        })
        
        self.onLayoutFinish.append(self.layoutFinished)
        self.checkUpdates()
        
        # Add notifiers
        config.plugins.OrangeAudio.file_source.addNotifier(self.configChanged, initial_call=False)
        config.plugins.OrangeAudio.merge_mode.addNotifier(self.configChanged, initial_call=False)
        config.plugins.OrangeAudio.token_path.addNotifier(self.configChanged, initial_call=False)

    def configChanged(self, *args):
        self.createSetup()

    def layoutFinished(self):
        self.setTitle(_("Orange Audio Setup"))
        self.createSetup()

    def keyNumberGlobal(self, number):
        if self["config"].getCurrent() and self["config"].getCurrent()[1] == config.plugins.OrangeAudio.token:
            current_value = config.plugins.OrangeAudio.token.value
            config.plugins.OrangeAudio.token.value = current_value + str(number)
            self["config"].invalidateCurrent()

    def ok(self):
        current = self["config"].getCurrent()
        if current:
            if current[1] == config.plugins.OrangeAudio.custom_file:
                self.openFileBrowser()
            elif current[1] == config.plugins.OrangeAudio.token_path:
                self.openFolderBrowser()
            else:
                ConfigListScreen.keyOK(self)

    def openFileBrowser(self):
        current_path = config.plugins.OrangeAudio.custom_file.value
        start_dir = os.path.dirname(current_path) if current_path else "/"
        self.session.openWithCallback(
            self.fileSelected,
            FileSelect,
            start_dir,
            selectFiles=True
        )

    def openFolderBrowser(self):
        current_path = config.plugins.OrangeAudio.token_path.value
        start_dir = current_path if current_path else "/"
        self.session.openWithCallback(
            self.folderSelected,
            FileSelect,
            start_dir,
            selectFiles=False
        )

    def fileSelected(self, path):
        if path:
            config.plugins.OrangeAudio.custom_file.value = path
            self["config"].invalidateCurrent()

    def folderSelected(self, path):
        if path:
            config.plugins.OrangeAudio.token_path.value = path
            self["config"].invalidateCurrent()

    def showAuthorInfo(self):
        self.session.open(
            MessageBox,
            _("Author: MNASR\n\nVersion: %s") % PLUGIN_VERSION,
            MessageBox.TYPE_INFO,
            timeout=10
        )

    def createSetup(self, *args):
        self.list = []
        self.list.append(getConfigListEntry(_("Target Plugin:"), config.plugins.OrangeAudio.target_plugin))
        self.list.append(getConfigListEntry(_("File Source:"), config.plugins.OrangeAudio.file_source))
        
        # Only show Custom File entry if File Source is set to Custom
        if config.plugins.OrangeAudio.file_source.value == "custom":
            self.list.append(getConfigListEntry(_("Custom File:"), config.plugins.OrangeAudio.custom_file))
        
        self.list.append(getConfigListEntry(_("Merge Mode:"), config.plugins.OrangeAudio.merge_mode))
        
        # Only show Token Code entry if Merge Mode is "merge_replace"
        if config.plugins.OrangeAudio.merge_mode.value == "merge_replace":
            self.list.append(getConfigListEntry(_("Token Code:"), config.plugins.OrangeAudio.token))
            self.list.append(getConfigListEntry(_("Token Folder:"), config.plugins.OrangeAudio.token_path))
        
        self.list.append(getConfigListEntry(_("Activate Orange Audio:"), config.plugins.OrangeAudio.activated))
        
        self["config"].list = self.list
        self["config"].l.setList(self.list)
    
    def save(self):
        for x in self["config"].list:
            x[1].save()
        
        if config.plugins.OrangeAudio.activated.value:
            self.mergeAndUpdateToken()
        else:
            self.session.open(
                MessageBox,
                _("Settings saved successfully!"),
                MessageBox.TYPE_INFO,
                timeout=10
            )
    
    def cancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()
    
    def importToken(self):
        token_file = os.path.join(config.plugins.OrangeAudio.token_path.value, "orangetoken.txt")
        try:
            if os.path.exists(token_file):
                with open(token_file, 'r') as f:
                    token = f.read().strip()
                config.plugins.OrangeAudio.token.value = token
                self.session.open(
                    MessageBox,
                    _("Token imported successfully!"),
                    MessageBox.TYPE_INFO,
                    timeout=10
                )
                self.createSetup()
            else:
                self.session.open(
                    MessageBox,
                    _("Token file not found!"),
                    MessageBox.TYPE_ERROR,
                    timeout=10
                )
        except Exception as e:
            self.session.open(
                MessageBox,
                _("Error importing token: %s") % str(e),
                MessageBox.TYPE_ERROR,
                timeout=10
            )

    def exportToken(self):
        token_file = os.path.join(config.plugins.OrangeAudio.token_path.value, "orangetoken.txt")
        token = config.plugins.OrangeAudio.token.value
        try:
            # Create directory if needed
            dir_path = os.path.dirname(token_file)
            if not os.path.exists(dir_path):
                os.makedirs(dir_path)
            
            with open(token_file, 'w') as f:
                f.write(token)
            self.session.open(
                MessageBox,
                _("Token exported successfully!"),
                MessageBox.TYPE_INFO,
                timeout=10
            )
        except Exception as e:
            self.session.open(
                MessageBox,
                _("Error exporting token: %s") % str(e),
                MessageBox.TYPE_ERROR,
                timeout=10
            )
    
    def mergeAndUpdateToken(self):
        try:
            plugin_path = os.path.dirname(os.path.realpath(__file__))
            user_token = config.plugins.OrangeAudio.token.value
            
            # Determine file source
            if config.plugins.OrangeAudio.file_source.value == "default":
                if config.plugins.OrangeAudio.target_plugin.value == "IPAudioPro":
                    orange_file = os.path.join(plugin_path, "orange_audio.json")
                else:
                    orange_file = os.path.join(plugin_path, "ipaudioplus_orange_list.json")
            else:
                orange_file = config.plugins.OrangeAudio.custom_file.value
                if not os.path.exists(orange_file):
                    raise Exception(_("Custom file does not exist"))
            
            # Load the selected file
            with open(orange_file, 'r') as f:
                orange_data = json.load(f)
            
            # Update tokens if requested
            if config.plugins.OrangeAudio.merge_mode.value == "merge_replace":
                if config.plugins.OrangeAudio.target_plugin.value == "IPAudioPro":
                    for category in orange_data.values():
                        for stream in category["streams"]:
                            # Replace any token= followed by digits
                            stream["url"] = re.sub(r'token=\d+', f'token={user_token}', stream["url"])
                else:
                    for channel in orange_data["User List"]["channels"]:
                        # Replace any token= followed by digits
                        channel["Url"] = re.sub(r'token=\d+', f'token={user_token}', channel["Url"])
            
            # Handle IPAudioPro
            if config.plugins.OrangeAudio.target_plugin.value == "IPAudioPro":
                target_file = "/etc/enigma2/IPAudioPro.json"
                
                if os.path.exists(target_file):
                    with open(target_file, 'r') as f:
                        target_data = json.load(f)
                else:
                    target_data = {}
                
                for key, value in orange_data.items():
                    target_data[key] = value
                
                with open(target_file, 'w') as f:
                    json.dump(target_data, f, indent=4)
                
                self.session.open(
                    MessageBox,
                    _("Orange Audio successfully merged with IPAudioPro!"),
                    MessageBox.TYPE_INFO,
                    timeout=10
                )
            
            # Handle IPAudioPlus
            else:
                target_file = "/etc/enigma2/ipaudioplus_user_list.json"
                
                if os.path.exists(target_file):
                    with open(target_file, 'r') as f:
                        target_data = json.load(f)
                else:
                    target_data = {"User List": {"Id": "USR", "channels": []}}
                
                # Create a map of existing channels by Name+Id
                existing_channels = {(ch["Name"], ch["Id"]): ch for ch in target_data["User List"]["channels"]}
                
                # Add or update channels from orange list
                for orange_ch in orange_data["User List"]["channels"]:
                    key = (orange_ch["Name"], orange_ch["Id"])
                    if key not in existing_channels:
                        target_data["User List"]["channels"].append(orange_ch)
                    else:
                        # Update URL if channel exists
                        existing_channels[key]["Url"] = orange_ch["Url"]
                
                with open(target_file, 'w') as f:
                    json.dump(target_data, f, indent=4)
                
                self.session.open(
                    MessageBox,
                    _("Orange Audio successfully merged with IPAudioPlus!"),
                    MessageBox.TYPE_INFO,
                    timeout=10
                )
                
        except Exception as e:
            self.session.open(
                MessageBox,
                _("Error merging files: %s") % str(e),
                MessageBox.TYPE_ERROR,
                timeout=10
            )

    def checkUpdates(self):
        try:
            url = b"https://raw.githubusercontent.com/popking159/OrangeAudio/main/version.txt"
            getPage(url, timeout=10).addCallback(self.parseUpdateData).addErrback(self.updateError)
        except Exception as e:
            print("[OrangeAudio] Update check error:", str(e))

    def updateError(self, error):
        print("[OrangeAudio] Failed to check for updates:", str(error))

    def parseUpdateData(self, data):
        if six.PY3:
            data = data.decode("utf-8")
        else:
            data = data.encode("utf-8")
        
        if data:
            lines = data.split("\n")
            for line in lines:
                if line.startswith("version="):
                    self.new_version = line.split("'")[1] if "'" in line else line.split('"')[1]
                if line.startswith("description="):
                    self.new_description = line.split("'")[1] if "'" in line else line.split('"')[1]
                    break
        
        if self.new_version and self.new_version != PLUGIN_VERSION:
            message = _("New version %s is available.\n\n%s\n\nDo you want to install now?") % (self.new_version, self.new_description)
            self.session.openWithCallback(
                self.installUpdate, 
                MessageBox, 
                message, 
                MessageBox.TYPE_YESNO,
                timeout=10
            )

    def installUpdate(self, answer=False):
        if answer:
            cmd = "wget https://raw.githubusercontent.com/popking159/OrangeAudio/main/installer.sh -O - | /bin/sh"
            self.session.open(Console, title=_("Installing update..."), cmdlist=[cmd], closeOnSuccess=False)

def main(session, **kwargs):
    session.open(OrangeAudioSetup)

def Plugins(**kwargs):
    return PluginDescriptor(
        name="Orange Audio",
        description="Merge Orange Audio streams with token support",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main,
        icon="plugin.png"
    )