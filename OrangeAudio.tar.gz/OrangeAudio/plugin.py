import os
import json
from enigma import eTimer
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap, NumberActionMap
from Components.Sources.StaticText import StaticText
from Components.Input import Input
from Components.config import config, ConfigSubsection, ConfigText, ConfigYesNo, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Plugins.Plugin import PluginDescriptor
from twisted.web.client import getPage
from Screens.Console import Console
import six

# Plugin version
PLUGIN_VERSION = "1.0"

config.plugins.OrangeAudio = ConfigSubsection()
config.plugins.OrangeAudio.token = ConfigText(default="0123456789", fixed_size=False)
config.plugins.OrangeAudio.activated = ConfigYesNo(default=False)
config.plugins.OrangeAudio.target_plugin = ConfigSelection(choices=[
    ("IPAudioPro", "IPAudioPro"),
    ("IPAudioPlus", "IPAudioPlus")
], default="IPAudioPro")

class OrangeAudioSetup(Screen, ConfigListScreen):
    skin = """
        <screen position="center,center" size="800,200" title="Orange Audio Setup">
   <widget name="config" position="10,10" size="780,135" scrollbarMode="showNever" itemHeight="45" />
   <widget source="key_red" render="Label" position="20,150" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
   <widget source="key_green" render="Label" position="220,150" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
   <eLabel name="" position="10,150" size="5,40" backgroundColor="red" foregroundColor="red" />
   <eLabel name="" position="210,150" size="5,40" backgroundColor="green" foregroundColor="green" />
</screen>
    """
    
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.setup_title = _("Orange Audio Setup")
        self.new_version = None
        self.new_description = None
        
        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))
        self["actions"] = ActionMap(["SetupActions", "ColorActions"],
        {
            "green": self.save,
            "red": self.cancel,
            "cancel": self.cancel,
            "ok": self.save,
            "info": self.showAuthorInfo,
        }, -2)
        
        self["numberActions"] = NumberActionMap(["NumberActions"],
        {
            "0": self.keyNumberGlobal,
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
        })
        
        ConfigListScreen.__init__(self, [], session=session)
        self.createSetup()
        self.checkUpdates()

    def keyNumberGlobal(self, number):
        if self["config"].getCurrent()[1] == config.plugins.OrangeAudio.token:
            current_value = config.plugins.OrangeAudio.token.value
            config.plugins.OrangeAudio.token.value = current_value + str(number)
            self["config"].invalidateCurrent()

    def showAuthorInfo(self):
        self.session.open(
            MessageBox,
            _("Author: MNASR\n\nVersion: %s") % PLUGIN_VERSION,
            MessageBox.TYPE_INFO
        )

    def createSetup(self):
        self.list = []
        self.list.append(getConfigListEntry(_("Target Plugin:"), config.plugins.OrangeAudio.target_plugin))
        self.list.append(getConfigListEntry(_("Token Code:"), config.plugins.OrangeAudio.token))
        self.list.append(getConfigListEntry(_("Activate Orange Audio:"), config.plugins.OrangeAudio.activated))
        self["config"].list = self.list
        self["config"].l.setList(self.list)
    
    def save(self):
        for x in self["config"].list:
            x[1].save()
        
        if config.plugins.OrangeAudio.activated.value:
            self.mergeAndUpdateToken()
        
        #self.close()
    
    def cancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()
    
    def mergeAndUpdateToken(self):
        try:
            plugin_path = os.path.dirname(os.path.realpath(__file__))
            user_token = config.plugins.OrangeAudio.token.value
            
            if config.plugins.OrangeAudio.target_plugin.value == "IPAudioPro":
                orange_file = os.path.join(plugin_path, "orange_audio.json")
                target_file = "/etc/enigma2/IPAudioPro.json"
                
                with open(orange_file, 'r') as f:
                    orange_data = json.load(f)
                
                for category in orange_data.values():
                    for stream in category["streams"]:
                        if "token=0123456789" in stream["url"]:
                            stream["url"] = stream["url"].replace("token=0123456789", f"token={user_token}")
                
                if os.path.exists(target_file):
                    with open(target_file, 'r') as f:
                        target_data = json.load(f)
                else:
                    target_data = {}
                
                for key, value in orange_data.items():
                    target_data[key] = value
                
                with open(target_file, 'w') as f:
                    json.dump(target_data, f, indent=4)
                
                self.session.open(MessageBox, _("Orange Audio successfully activated with IPAudioPro!"), MessageBox.TYPE_INFO)
            
            else:
                orange_file = os.path.join(plugin_path, "ipaudioplus_orange_list.json")
                target_file = "/etc/enigma2/ipaudioplus_user_list.json"
                
                with open(orange_file, 'r') as f:
                    orange_data = json.load(f)
                
                orange_channels = orange_data["User List"]["channels"]
                for channel in orange_channels:
                    if "token=0123456789" in channel["Url"]:
                        channel["Url"] = channel["Url"].replace("token=0123456789", f"token={user_token}")
                
                if os.path.exists(target_file):
                    with open(target_file, 'r') as f:
                        target_data = json.load(f)
                else:
                    target_data = {"User List": {"Id": "USR", "channels": []}}
                
                existing_channels = {(ch["Name"], ch["Id"]): ch for ch in target_data["User List"]["channels"]}
                
                for orange_ch in orange_channels:
                    key = (orange_ch["Name"], orange_ch["Id"])
                    if key not in existing_channels:
                        target_data["User List"]["channels"].append(orange_ch)
                    else:
                        existing_channels[key]["Url"] = orange_ch["Url"]
                
                with open(target_file, 'w') as f:
                    json.dump(target_data, f, indent=4)
                
                self.session.open(MessageBox, _("Orange Audio successfully activated with IPAudioPlus!"), MessageBox.TYPE_INFO)
                
        except Exception as e:
            self.session.open(MessageBox, _("Error merging files: %s") % str(e), MessageBox.TYPE_ERROR)

    def checkUpdates(self):
        try:
            url = b"https://raw.githubusercontent.com/popking159/OrangeAudio/main/version.txt"
            getPage(url, timeout=10).addCallback(self.parseUpdateData).addErrback(self.updateError)
        except Exception as e:
            print("[OrangeAudio] Update check error:", str(e))

    def updateError(self, error):
        print("[OrangeAudio] Failed to check for updates:", str(error))

    def parseUpdateData(self, data):
        if six.PY3:
            data = data.decode("utf-8")
        else:
            data = data.encode("utf-8")
        
        if data:
            lines = data.split("\n")
            for line in lines:
                if line.startswith("version="):
                    self.new_version = line.split("'")[1] if "'" in line else line.split('"')[1]
                if line.startswith("description="):
                    self.new_description = line.split("'")[1] if "'" in line else line.split('"')[1]
                    break
        
        if self.new_version and self.new_version != PLUGIN_VERSION:
            message = _("New version %s is available.\n\n%s\n\nDo you want to install now?") % (self.new_version, self.new_description)
            self.session.openWithCallback(self.installUpdate, MessageBox, message, MessageBox.TYPE_YESNO)

    def installUpdate(self, answer=False):
        if answer:
            cmd = "wget https://raw.githubusercontent.com/popking159/OrangeAudio/main/installer.sh -O - | /bin/sh"
            self.session.open(Console, title=_("Installing update..."), cmdlist=[cmd], closeOnSuccess=False)

def main(session, **kwargs):
    session.open(OrangeAudioSetup)

def Plugins(**kwargs):
    return PluginDescriptor(
        name="Orange Audio",
        description="Merge Orange Audio streams with token support",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main,
        icon="plugin.png"
    )