import os
import json
import re
from enigma import eTimer
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap, NumberActionMap
from Components.Sources.StaticText import StaticText
from Components.Input import Input
from Components.config import config, ConfigSubsection, ConfigText, ConfigYesNo, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.ConfigList import ConfigList
from Plugins.Plugin import PluginDescriptor
from Components.FileList import FileList
from Components.Label import Label
from twisted.web.client import getPage
from Screens.Console import Console
import six
import logging
log = logging.getLogger("OrangeAudio")

# Plugin version
PLUGIN_VERSION = "1.2"

config.plugins.OrangeAudio = ConfigSubsection()
config.plugins.OrangeAudio.token = ConfigText(default="0123456789", fixed_size=False)
config.plugins.OrangeAudio.activated = ConfigYesNo(default=False)
config.plugins.OrangeAudio.m3u_file = ConfigText(default="", fixed_size=False)
config.plugins.OrangeAudio.target_plugin = ConfigSelection(choices=[
    ("IPAudioPro", "IPAudioPro"),
    ("IPAudioPlus", "IPAudioPlus")
], default="IPAudioPro")
config.plugins.OrangeAudio.file_source = ConfigSelection(choices=[
    ("default", "Default Files"),
    ("custom", "Custom JSON File")
], default="default")
config.plugins.OrangeAudio.custom_file = ConfigText(default="", fixed_size=False)
config.plugins.OrangeAudio.merge_mode = ConfigSelection(choices=[
    ("merge_replace", "Merge and Replace Token"),
    ("merge_only", "Merge Only")
], default="merge_replace")
config.plugins.OrangeAudio.token_path = ConfigText(default="/etc/enigma2/", fixed_size=False)

class SettingsScreen(Screen, ConfigListScreen):
    skin = """
        <screen position="center,center" size="800,380" title="Orange Audio Settings" flags="wfBorder">
            <widget name="config" position="10,10" size="780,315" scrollbarMode="showOnDemand" itemHeight="45" />
            <widget source="key_red" render="Label" position="20,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget source="key_green" render="Label" position="220,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget source="key_yellow" render="Label" position="420,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget source="key_blue" render="Label" position="620,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <eLabel name="" position="10,330" size="5,40" backgroundColor="red" foregroundColor="red" />
            <eLabel name="" position="210,330" size="5,40" backgroundColor="green" foregroundColor="green" />
            <eLabel name="" position="410,330" size="5,40" backgroundColor="yellow" foregroundColor="yellow" />
            <eLabel name="" position="610,330" size="5,40" backgroundColor="blue" foregroundColor="blue" />
        </screen>
    """
    
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.list = []
        
        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))
        self["key_yellow"] = StaticText(_("Import Token"))
        self["key_blue"] = StaticText(_("Export Token"))
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions"],
        {
            "green": self.save,
            "red": self.cancel,
            "cancel": self.cancel,
            "ok": self.ok,
            "yellow": self.importToken,
            "blue": self.exportToken
        }, -2)
        
        ConfigListScreen.__init__(self, self.list, session=session)
        self.onLayoutFinish.append(self.layoutFinished)
    
    def layoutFinished(self):
        self.setTitle(_("Orange Audio Settings"))
        self.createSetup()
    
    def createSetup(self):
        self.list = []
        self.list.append(getConfigListEntry(_("Token Code:"), config.plugins.OrangeAudio.token))
        self.list.append(getConfigListEntry(_("Token Folder:"), config.plugins.OrangeAudio.token_path))
        self.list.append(getConfigListEntry(_("Custom JSON File:"), config.plugins.OrangeAudio.custom_file))
        self.delete_plus_config = ConfigYesNo(default=False)
        self.delete_pro_config = ConfigYesNo(default=False)
        self.list.append(getConfigListEntry(_("Delete IPAudio Plus Playlist:"), self.delete_plus_config))
        self.list.append(getConfigListEntry(_("Delete IPAudio Pro Playlist:"), self.delete_pro_config))
        self["config"].list = self.list
        self["config"].l.setList(self.list)
    
    def ok(self):
        current = self["config"].getCurrent()
        if current:
            if current[1] == config.plugins.OrangeAudio.token_path:
                self.openFolderBrowser()
            elif current[1] == config.plugins.OrangeAudio.custom_file:
                self.openFileBrowser()
            else:
                ConfigListScreen.keyOK(self)

    def openFileBrowser(self):
        current_path = config.plugins.OrangeAudio.custom_file.value
        # If current path exists, use its directory, otherwise default to /media/hdd/
        if current_path and os.path.exists(current_path):
            start_dir = os.path.dirname(current_path)
        else:
            start_dir = "/media/hdd/"  # Default to HDD where files are typically stored
        
        self.session.openWithCallback(
            self.fileSelected,
            FileSelect,
            start_dir,
            selectFiles=True,
            fileFilter="json"
        )


    def openFolderBrowser(self):
        current_path = config.plugins.OrangeAudio.token_path.value
        # Use current path if it exists, otherwise start from root
        start_dir = current_path if current_path and os.path.exists(current_path) else "/"
        self.session.openWithCallback(
            self.folderSelected,
            FileSelect,
            start_dir,
            selectFiles=False  # Important for folder selection mode
        )
    
    def fileSelected(self, path):
        if path:
            # Convert to absolute path and store
            abs_path = os.path.abspath(path)
            config.plugins.OrangeAudio.custom_file.value = abs_path
            self["config"].invalidateCurrent()
            print("[DEBUG] Stored file path:", abs_path)  # For debugging

    def folderSelected(self, path):
        if path:
            # Get absolute path and ensure it ends with /
            full_path = os.path.abspath(path)
            if not full_path.endswith('/'):
                full_path += '/'
            config.plugins.OrangeAudio.token_path.value = full_path
            self["config"].invalidateCurrent()

    def save(self):
        for x in self["config"].list:
            x[1].save()
        
        # Handle playlist deletion - only if user explicitly enabled it
        if self.delete_plus_config.value:  # Check the actual config value
            try:
                if os.path.exists("/etc/enigma2/ipaudioplus_user_list.json"):
                    os.remove("/etc/enigma2/ipaudioplus_user_list.json")
                    self.session.open(MessageBox, _("IPAudio Plus playlist deleted successfully!"), MessageBox.TYPE_INFO)
                else:
                    self.session.open(MessageBox, _("IPAudio Plus playlist not found!"), MessageBox.TYPE_INFO)
            except Exception as e:
                self.session.open(MessageBox, _("Error deleting IPAudio Plus playlist: %s") % str(e), MessageBox.TYPE_ERROR)
        
        if self.delete_pro_config.value:  # Check the actual config value
            try:
                if os.path.exists("/etc/enigma2/IPAudioPro.json"):
                    os.remove("/etc/enigma2/IPAudioPro.json")
                    self.session.open(MessageBox, _("IPAudio Pro playlist deleted successfully!"), MessageBox.TYPE_INFO)
                else:
                    self.session.open(MessageBox, _("IPAudio Pro playlist not found!"), MessageBox.TYPE_INFO)
            except Exception as e:
                self.session.open(MessageBox, _("Error deleting IPAudio Pro playlist: %s") % str(e), MessageBox.TYPE_ERROR)
        
        self.close()
    
    def cancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()
    
    def importToken(self):
        token_file = os.path.join(config.plugins.OrangeAudio.token_path.value, "orangetoken.txt")
        try:
            if os.path.exists(token_file):
                with open(token_file, 'r') as f:
                    token = f.read().strip()
                config.plugins.OrangeAudio.token.value = token
                self.session.open(
                    MessageBox,
                    _("Token imported successfully!"),
                    MessageBox.TYPE_INFO,
                    timeout=10
                )
                self.createSetup()
            else:
                self.session.open(
                    MessageBox,
                    _("Token file not found!"),
                    MessageBox.TYPE_ERROR,
                    timeout=10
                )
        except Exception as e:
            self.session.open(
                MessageBox,
                _("Error importing token: %s") % str(e),
                MessageBox.TYPE_ERROR,
                timeout=10
            )
    
    def exportToken(self):
        token_file = os.path.join(config.plugins.OrangeAudio.token_path.value, "orangetoken.txt")
        token = config.plugins.OrangeAudio.token.value
        try:
            # Create directory if needed
            dir_path = os.path.dirname(token_file)
            if not os.path.exists(dir_path):
                os.makedirs(dir_path)
            
            with open(token_file, 'w') as f:
                f.write(token)
            self.session.open(
                MessageBox,
                _("Token exported successfully!"),
                MessageBox.TYPE_INFO,
                timeout=10
            )
        except Exception as e:
            self.session.open(
                MessageBox,
                _("Error exporting token: %s") % str(e),
                MessageBox.TYPE_ERROR,
                timeout=10
            )

class FileSelect(Screen):
    skin = """
        <screen name="FileSelect" position="center,center" size="820,590" title="Select File" flags="wfBorder">
            <eLabel name="" position="10,550" size="5,40" backgroundColor="red" foregroundColor="red" />
            <eLabel name="" position="210,550" size="5,40" backgroundColor="green" foregroundColor="green" />
            <widget name="list_head" position="10,10" size="800,38" foregroundColor="#00cccc40" font="Regular; 26" />
            <widget source="key_red" render="Label" position="20,550" zPosition="1" size="170,40" font="Regular;26" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget source="key_green" render="Label" position="220,550" zPosition="1" size="170,40" font="Regular;26" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget name="filelist" position="10,50" zPosition="2" size="800,483" scrollbarMode="showOnDemand" />
        </screen>"""

    def __init__(self, session, currentDir, selectFiles=True, fileFilter=None):
        if not currentDir.startswith('/'):
            currentDir = os.path.abspath(currentDir)
        if not os.path.exists(currentDir):
            currentDir = "/"  # Fallback to root
        Screen.__init__(self, session)
        self.selectFiles = selectFiles
        self.fileFilter = fileFilter
        title = _("Select File")
        if fileFilter == "m3u":
            title = _("Select M3U File")
        elif fileFilter == "json":
            title = _("Select JSON File")
        self.setTitle(title)

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"],
        {
            "cancel": self.exit,
            "red": self.exit,
            "green": self.saveSelection,
            "ok": self.okClicked,
            "left": self.left,
            "right": self.right,
            "down": self.down,
            "up": self.up
        }, -1)

        self["key_red"] = StaticText(_("Close"))
        self["key_green"] = StaticText(_("Select"))
        self["list_head"] = Label()

        # Initialize filelist with the correct starting directory
        self.filelist = FileList(currentDir, showDirectories=True, showFiles=selectFiles)
        self["filelist"] = self.filelist
        
        # Filter files if needed
        if selectFiles and fileFilter:
            self.filterFiles()
        
        self.onLayoutFinish.append(self.layoutFinished)
        self.updateHead()

    def filterFiles(self):
        """Filter the file list based on fileFilter"""
        filtered_list = []
        for item in self.filelist.list:
            # item[0][0] is the filename, item[0][1] is True for directories
            if item[0][1]:  # It's a directory - keep it
                filtered_list.append(item)
            elif item[0][0]:  # It's a file
                if self.fileFilter == "m3u" and item[0][0].lower().endswith('.m3u'):
                    filtered_list.append(item)
                elif self.fileFilter == "json" and item[0][0].lower().endswith('.json'):
                    filtered_list.append(item)
        self.filelist.list = filtered_list
        self.filelist.l.setList(filtered_list)

    def layoutFinished(self):
        idx = 0
        self["filelist"].moveToIndex(idx)

    def up(self):
        self["filelist"].up()
        self.updateHead()

    def down(self):
        self["filelist"].down()
        self.updateHead()

    def left(self):
        self["filelist"].pageUp()
        self.updateHead()

    def right(self):
        self["filelist"].pageDown()
        self.updateHead()

    def updateHead(self):
        curdir = self["filelist"].getCurrentDirectory()
        self["list_head"].setText(curdir)

    def saveSelection(self):
        if self.selectFiles:
            selected = self["filelist"].getFilename()
            if selected:
                # Get the current directory and combine with selected filename
                current_dir = self["filelist"].getCurrentDirectory()
                full_path = os.path.join(current_dir, selected)
                # Normalize the path to remove any ../ or ./ references
                full_path = os.path.normpath(full_path)
                # Ensure we return absolute path
                full_path = os.path.abspath(full_path)
                self.close(full_path)
            else:
                self.session.open(MessageBox, _("Please select a file, not a directory."), MessageBox.TYPE_ERROR, timeout=10)
        else:
            # For directory selection, return the current directory
            selected = self["filelist"].getCurrentDirectory()
            # Normalize the path and ensure it's absolute
            full_path = os.path.normpath(selected)
            full_path = os.path.abspath(full_path)
            # Ensure directory paths end with /
            if not full_path.endswith('/'):
                full_path += '/'
            self.close(full_path)

    def okClicked(self):
        if self.filelist.canDescent():
            self.filelist.descent()
            # Re-filter files after descending into directory
            if self.selectFiles and self.fileFilter:
                self.filterFiles()
            self.updateHead()
        elif self.selectFiles:
            self.saveSelection()

    def exit(self):
        self.close(None)

class M3UConverterScreen(Screen, ConfigListScreen):
    skin = """
        <screen position="center,center" size="800,380" title="M3U Converter" flags="wfBorder">
            <widget name="config" position="10,10" size="780,315" scrollbarMode="showOnDemand" itemHeight="45" />
            <widget source="key_red" render="Label" position="20,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget source="key_green" render="Label" position="220,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <eLabel name="" position="10,330" size="5,40" backgroundColor="red" foregroundColor="red" />
            <eLabel name="" position="210,330" size="5,40" backgroundColor="green" foregroundColor="green" />
        </screen>
    """
    
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.list = []
        
        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Convert"))
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions"],
        {
            "green": self.convert,
            "red": self.cancel,
            "cancel": self.cancel,
            "ok": self.ok,
        }, -2)
        
        ConfigListScreen.__init__(self, self.list, session=session)
        self.onLayoutFinish.append(self.layoutFinished)
    
    def layoutFinished(self):
        self.setTitle(_("M3U Converter"))
        self.createSetup()
    
    def createSetup(self):
        self.list = []
        self.list.append(getConfigListEntry(_("M3U File:"), config.plugins.OrangeAudio.m3u_file))
        self["config"].list = self.list
        self["config"].l.setList(self.list)
    
    def ok(self):
        current = self["config"].getCurrent()
        if current and current[1] == config.plugins.OrangeAudio.m3u_file:
            self.openFileBrowser()
        else:
            ConfigListScreen.keyOK(self)
    
    def openFileBrowser(self):
        current_path = config.plugins.OrangeAudio.m3u_file.value
        start_dir = os.path.dirname(current_path) if current_path else "/"
        
        self.session.openWithCallback(
            self.fileSelected,
            FileSelect,
            start_dir,
            selectFiles=True
        )
    
    def fileSelected(self, path):
        if path:
            config.plugins.OrangeAudio.m3u_file.value = path
            config.plugins.OrangeAudio.m3u_file.save()  # Save the path to config
            self["config"].invalidateCurrent()
    
    def convert(self):
        m3u_path = config.plugins.OrangeAudio.m3u_file.value
        
        if not m3u_path or not os.path.exists(m3u_path):
            self.session.open(MessageBox, _("Please select a valid M3U file"), MessageBox.TYPE_ERROR)
            return
        
        try:
            output_dir = os.path.dirname(m3u_path)
            orange_path = os.path.join(output_dir, "ipaudiopro_orange_list.json")
            
            # First convert M3U to ipaudiopro_orange_list.json format
            orange_data = self.convert_m3u_to_orange(m3u_path)
            
            # Save ipaudiopro_orange_list.json
            with open(orange_path, 'w') as f:
                json.dump(orange_data, f, indent=4)
            
            # Then convert to IPAudioPlus format
            ipaudio_data = self.convert_orange_to_ipaudio(orange_data)
            
            # Save IPAudioPlus format
            ipaudio_path = os.path.join(output_dir, "ipaudioplus_orange_list.json")
            with open(ipaudio_path, 'w') as f:
                json.dump(ipaudio_data, f, indent=4)
            
            self.session.open(
                MessageBox,
                _("M3U converted successfully!\n\nFiles saved in:\n%s") % output_dir,
                MessageBox.TYPE_INFO
            )
        except Exception as e:
            self.session.open(
                MessageBox,
                _("Error converting M3U: %s") % str(e),
                MessageBox.TYPE_ERROR
            )
    
    def convert_m3u_to_orange(self, m3u_path):
        """Convert M3U file to Orange Audio JSON format"""
        # Initialize the data structures
        orange_data = {
            "Orange": {"streams": []},
            "Middle": {"streams": []},
            "Delay": {"streams": []}
        }
        
        # Read the M3U file
        with open(m3u_path, 'r') as f:
            content = f.readlines()
        
        # Process each channel entry
        channel_id = 1
        i = 0
        while i < len(content):
            line = content[i].strip()
            if line.startswith('#EXTINF'):
                # Parse the EXTINF line
                extinf = line
                tvg_name = re.search(r'tvg-name="([^"]+)"', extinf)
                tvg_id = re.search(r'tvg-id="([^"]+)"', extinf)
                display_name = tvg_name.group(1) if tvg_name else extinf.split(',')[-1]
                name = tvg_id.group(1) if tvg_id else display_name.lower().replace(' ', '_')
                
                # Get the URL from the next line
                if i + 1 < len(content):
                    url = content[i+1].strip()
                    
                    # Determine the provider (Orange, Middle, Delay)
                    provider = None
                    if 'Orange' in display_name:
                        provider = 'Orange'
                    elif 'Middle' in display_name:
                        provider = 'Middle'
                    elif 'Delay' in display_name:
                        provider = 'Delay'
                    
                    # Process for Orange Audio format
                    if provider:
                        # Replace all audio channel name patterns with "bs_"
                        processed_name = re.sub(r'(Orange|Middle)-Audio|Delay_Audio', 'bs_', name)
                        
                        orange_data[provider]['streams'].append({
                            "display_name": display_name,
                            "url": url,
                            "name": processed_name
                        })
                    
                    i += 1  # Skip the URL line
            i += 1
        
        return orange_data

    def convert_orange_to_ipaudio(self, orange_data):
        """Convert Orange Audio format to IPAudioPlus format"""
        ipaudio_data = {
            "User List": {
                "Id": "USR",
                "channels": []
            }
        }
        
        channel_id = 1
        # Process all categories (Orange, Middle, Delay)
        for category, streams in orange_data.items():
            for stream in streams["streams"]:
                ipaudio_data["User List"]["channels"].append({
                    "Name": stream["display_name"],
                    "Id": str(channel_id),
                    "Url": stream["url"]
                })
                channel_id += 1
        
        return ipaudio_data
    
    def cancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()

class OrangeAudioSetup(Screen, ConfigListScreen):
    skin = """
        <screen position="center,center" size="800,380" title="Orange Audio Setup" flags="wfBorder">
            <widget name="config" position="10,10" size="780,315" scrollbarMode="showOnDemand" itemHeight="45" />
            <widget source="key_red" render="Label" position="20,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget source="key_green" render="Label" position="220,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget source="key_yellow" render="Label" position="420,330" zPosition="1" size="140,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <widget source="key_blue" render="Label" position="620,330" zPosition="1" size="180,40" font="Regular;24" halign="left" valign="center" backgroundColor="background" transparent="1" />
            <eLabel name="" position="10,330" size="5,40" backgroundColor="red" foregroundColor="red" />
            <eLabel name="" position="210,330" size="5,40" backgroundColor="green" foregroundColor="green" />
            <eLabel name="" position="410,330" size="5,40" backgroundColor="yellow" foregroundColor="yellow" />
            <eLabel name="" position="610,330" size="5,40" backgroundColor="blue" foregroundColor="blue" />
        </screen>
    """
    
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.setup_title = _("Orange Audio Setup")
        self.new_version = None
        self.new_description = None
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=session)
        self.setupUI()
        self.checkUpdates()
        self.onLayoutFinish.append(self.layoutFinished)

    def setupUI(self):
        """Initialize all UI components"""
        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))
        self["key_yellow"] = StaticText(_("Settings"))
        self["key_blue"] = StaticText(_("M3U Converter"))
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions"],
        {
            "green": self.save,
            "red": self.cancel,
            "cancel": self.cancel,
            "ok": self.ok,
            "info": self.showAuthorInfo,
            "yellow": self.openSettings,
            "blue": self.openM3UConverter
        }, -2)
        
        self["numberActions"] = NumberActionMap(["NumberActions"],
        {
            "0": self.keyNumberGlobal,
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
        })
        
    def layoutFinished(self):
        """Called when UI layout is complete"""
        self.setTitle(self.setup_title)
        self.createSetup()

    def createSetup(self):
        try:
            log.debug("Creating setup...")
            self.list = []
            self.list.append(getConfigListEntry(_("Target Plugin:"), config.plugins.OrangeAudio.target_plugin))
            self.list.append(getConfigListEntry(_("File Source:"), config.plugins.OrangeAudio.file_source))                       
            self.list.append(getConfigListEntry(_("Merge Mode:"), config.plugins.OrangeAudio.merge_mode))
            self.list.append(getConfigListEntry(_("Activate Orange Audio:"), config.plugins.OrangeAudio.activated))
            
            self["config"].list = self.list
            self["config"].l.setList(self.list)
        except Exception as e:
            log.error("Error in createSetup: %s", str(e))
            raise

    def keyNumberGlobal(self, number):
        if self["config"].getCurrent() and self["config"].getCurrent()[1] == config.plugins.OrangeAudio.token:
            current_value = config.plugins.OrangeAudio.token.value
            config.plugins.OrangeAudio.token.value = current_value + str(number)
            self["config"].invalidateCurrent()

    def ok(self):
        current = self["config"].getCurrent()
        if current:
            if current[1] == config.plugins.OrangeAudio.custom_file:
                self.openFileBrowser()
            elif current[1] == config.plugins.OrangeAudio.token_path:
                self.openFolderBrowser()
            else:
                ConfigListScreen.keyOK(self)

    def openFileBrowser(self):
        current_path = config.plugins.OrangeAudio.custom_file.value
        start_dir = os.path.dirname(current_path) if current_path else "/"
        self.session.openWithCallback(
            self.fileSelected,
            FileSelect,
            start_dir,
            selectFiles=True
        )

    def openFolderBrowser(self):
        current_path = config.plugins.OrangeAudio.token_path.value
        start_dir = current_path if current_path else "/"
        self.session.openWithCallback(
            self.folderSelected,
            FileSelect,
            start_dir,
            selectFiles=False
        )

    def fileSelected(self, path):
        if path:
            # Temporarily disable notifiers
            notifiers = []
            for x in config.plugins.OrangeAudio.dict().values():
                if hasattr(x, "notifiers"):
                    notifiers.extend(x.notifiers)
                    x.notifiers = []
            
            try:
                config.plugins.OrangeAudio.custom_file.value = path
                self["config"].invalidateCurrent()
            finally:
                # Restore notifiers
                for x in config.plugins.OrangeAudio.dict().values():
                    if hasattr(x, "notifiers"):
                        x.notifiers = notifiers

    def folderSelected(self, path):
        if path:
            notifiers = []
            for x in config.plugins.OrangeAudio.dict().values():
                if hasattr(x, "notifiers"):
                    notifiers.extend(x.notifiers)
                    x.notifiers = []
            
            try:
                config.plugins.OrangeAudio.token_path.value = path
                self["config"].invalidateCurrent()
            finally:
                # Restore notifiers
                for x in config.plugins.OrangeAudio.dict().values():
                    if hasattr(x, "notifiers"):
                        x.notifiers = notifiers

    def showAuthorInfo(self):
        self.session.open(
            MessageBox,
            _("Author: MNASR\n\nVersion: %s") % PLUGIN_VERSION,
            MessageBox.TYPE_INFO,
            timeout=10
        )

    def openM3UConverter(self):
        self.session.open(M3UConverterScreen)
    


    def openSettings(self):
        self.session.open(SettingsScreen)

    def save(self):
        for x in self["config"].list:
            x[1].save()
        
        if config.plugins.OrangeAudio.activated.value:
            self.mergeAndUpdateToken()
        else:
            self.session.open(
                MessageBox,
                _("Settings saved successfully!"),
                MessageBox.TYPE_INFO,
                timeout=10
            )
    
    def cancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()
    
    def mergeAndUpdateToken(self):
        try:
            plugin_path = os.path.dirname(os.path.realpath(__file__))
            user_token = config.plugins.OrangeAudio.token.value
            
            # Determine file source with proper path handling
            if config.plugins.OrangeAudio.file_source.value == "default":
                # Use built-in default files
                if config.plugins.OrangeAudio.target_plugin.value == "IPAudioPro":
                    orange_file = os.path.join(plugin_path, "ipaudiopro_orange_list.json")
                else:
                    orange_file = os.path.join(plugin_path, "ipaudioplus_orange_list.json")
            else:
                # Handle custom file path
                orange_file = config.plugins.OrangeAudio.custom_file.value
                if not orange_file:  # Empty path
                    raise Exception(_("No custom file specified"))
                
                # Convert to absolute path if relative
                if not os.path.isabs(orange_file):
                    orange_file = os.path.abspath(orange_file)
                
                print("[OrangeAudio] Using custom file:", orange_file)  # Debug output
                
                if not os.path.exists(orange_file):
                    raise Exception(_("File not found at: %s") % orange_file)

            # Read the source file
            with open(orange_file, 'r') as f:
                orange_data = json.load(f)
            
            # Update tokens if requested
            if config.plugins.OrangeAudio.merge_mode.value == "merge_replace":
                if config.plugins.OrangeAudio.target_plugin.value == "IPAudioPro":
                    for category in orange_data.values():
                        for stream in category["streams"]:
                            # Replace any token= followed by digits
                            stream["url"] = re.sub(r'token=\d+', f'token={user_token}', stream["url"])
                else:
                    for channel in orange_data["User List"]["channels"]:
                        # Replace any token= followed by digits
                        channel["Url"] = re.sub(r'token=\d+', f'token={user_token}', channel["Url"])

            # Handle IPAudioPro merge
            if config.plugins.OrangeAudio.target_plugin.value == "IPAudioPro":
                target_file = "/etc/enigma2/IPAudioPro.json"
                
                if os.path.exists(target_file):
                    with open(target_file, 'r') as f:
                        target_data = json.load(f)
                else:
                    target_data = {}
                
                # Merge the data
                for key, value in orange_data.items():
                    target_data[key] = value
                
                # Create directory if needed
                target_dir = os.path.dirname(target_file)
                if not os.path.exists(target_dir):
                    os.makedirs(target_dir)
                
                # Write the merged file
                with open(target_file, 'w') as f:
                    json.dump(target_data, f, indent=4)
                
                self.session.open(
                    MessageBox,
                    _("Orange Audio successfully merged with IPAudioPro!\n\nSaved to: %s") % target_file,
                    MessageBox.TYPE_INFO,
                    timeout=10
                )
            
            # Handle IPAudioPlus merge
            else:
                target_file = "/etc/enigma2/ipaudioplus_user_list.json"
                
                if os.path.exists(target_file):
                    with open(target_file, 'r') as f:
                        target_data = json.load(f)
                else:
                    target_data = {"User List": {"Id": "USR", "channels": []}}
                
                # Create a map of existing channels by Name+Id
                existing_channels = {(ch["Name"], ch["Id"]): ch for ch in target_data["User List"]["channels"]}
                
                # Add or update channels from orange list
                for orange_ch in orange_data["User List"]["channels"]:
                    key = (orange_ch["Name"], orange_ch["Id"])
                    if key not in existing_channels:
                        target_data["User List"]["channels"].append(orange_ch)
                    else:
                        # Update URL if channel exists
                        existing_channels[key]["Url"] = orange_ch["Url"]
                
                # Create directory if needed
                target_dir = os.path.dirname(target_file)
                if not os.path.exists(target_dir):
                    os.makedirs(target_dir)
                
                # Write the merged file
                with open(target_file, 'w') as f:
                    json.dump(target_data, f, indent=4)
                
                self.session.open(
                    MessageBox,
                    _("Orange Audio successfully merged with IPAudioPlus!\n\nSaved to: %s") % target_file,
                    MessageBox.TYPE_INFO,
                    timeout=10
                )
                
        except Exception as e:
            error_msg = _("Error merging files: %s") % str(e)
            print("[OrangeAudio] Merge error:", error_msg)  # Debug output
            self.session.open(
                MessageBox,
                error_msg,
                MessageBox.TYPE_ERROR,
                timeout=10
            )

    def checkUpdates(self):
        try:
            url = b"https://raw.githubusercontent.com/popking159/OrangeAudio/main/version.txt"
            getPage(url, timeout=10).addCallback(self.parseUpdateData).addErrback(self.updateError)
        except Exception as e:
            print("[OrangeAudio] Update check error:", str(e))

    def updateError(self, error):
        print("[OrangeAudio] Failed to check for updates:", str(error))

    def parseUpdateData(self, data):
        if six.PY3:
            data = data.decode("utf-8")
        else:
            data = data.encode("utf-8")
        
        if data:
            lines = data.split("\n")
            for line in lines:
                if line.startswith("version="):
                    self.new_version = line.split("'")[1] if "'" in line else line.split('"')[1]
                if line.startswith("description="):
                    self.new_description = line.split("'")[1] if "'" in line else line.split('"')[1]
                    break
        
        if self.new_version and self.new_version != PLUGIN_VERSION:
            message = _("New version %s is available.\n\n%s\n\nDo you want to install now?") % (self.new_version, self.new_description)
            self.session.openWithCallback(
                self.installUpdate, 
                MessageBox, 
                message, 
                MessageBox.TYPE_YESNO,
                timeout=10
            )

    def installUpdate(self, answer=False):
        if answer:
            cmd = "wget https://raw.githubusercontent.com/popking159/OrangeAudio/main/installer.sh -O - | /bin/sh"
            self.session.open(Console, title=_("Installing update..."), cmdlist=[cmd], closeOnSuccess=False)

def main(session, **kwargs):
    session.open(OrangeAudioSetup)

def Plugins(**kwargs):
    return PluginDescriptor(
        name="Orange Audio",
        description="Merge Orange Audio streams with token support",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main,
        icon="plugin.png"
    )